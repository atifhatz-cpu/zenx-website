// Draw-on animation for hero chart
  document.querySelectorAll('.path-draw').forEach(function(path){
    var len = path.getTotalLength();
    path.style.strokeDasharray = len;
    path.style.strokeDashoffset = len;
    path.getBoundingClientRect(); // force reflow
    path.style.transition = 'stroke-dashoffset 1.8s cubic-bezier(.4,.1,.2,1)';
    requestAnimationFrame(function(){
      setTimeout(function(){ path.style.strokeDashoffset = 0; }, 250);
    });
  });

  // Scroll reveal
  var revealEls = document.querySelectorAll('.reveal');
  var io = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(entry.isIntersecting){
        entry.target.classList.add('is-visible');
        io.unobserve(entry.target);
      }
    });
  }, {threshold:0.15});
  revealEls.forEach(function(el){ io.observe(el); });